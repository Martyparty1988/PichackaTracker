
import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
import path from 'path'

export default defineConfig({
  plugins: [react()],
  server: {
    host: '0.0.0.0',
    port: 5173,
    hmr: {
      clientPort: 443,
      host: '0.0.0.0'
    },
    allowedHosts: [
      'cf240e29-1b67-40b7-9bbc-c7db21dbbbe9-00-10g54iue3wleg.riker.replit.dev'
    ]
  },
  resolve: {
    alias: {
      '@': path.resolve(__dirname, './src')
    }
  }
})
