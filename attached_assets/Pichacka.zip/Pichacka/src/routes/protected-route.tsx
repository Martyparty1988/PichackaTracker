
import { Navigate, Outlet } from 'react-router-dom';

export const ProtectedRoute = () => {
  const user = JSON.parse(localStorage.getItem('user') || 'null');

  if (!user) {
    return <Navigate to="/login" replace />;
  }

  return <Outlet />;
};
