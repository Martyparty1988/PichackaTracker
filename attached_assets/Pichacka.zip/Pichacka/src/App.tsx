
import { BrowserRouter as Router } from 'react-router-dom'
import { Toaster } from 'react-hot-toast'
import { AppRoutes } from './routes'
import { ThemeProvider } from './components/theme-provider'

function App() {
  return (
    <ThemeProvider defaultTheme="light">
      <Router>
        <AppRoutes />
        <Toaster position="top-right" />
      </Router>
    </ThemeProvider>
  )
}

export default App
