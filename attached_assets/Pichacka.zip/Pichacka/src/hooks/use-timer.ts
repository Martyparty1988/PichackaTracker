
import { useState, useEffect, useCallback } from 'react';

interface UseTimerProps {
  onTick?: (seconds: number) => void;
}

export const useTimer = ({ onTick }: UseTimerProps = {}) => {
  const [isRunning, setIsRunning] = useState(false);
  const [seconds, setSeconds] = useState(0);
  const [person, setPerson] = useState<'maru' | 'marty'>('maru');

  useEffect(() => {
    let interval: NodeJS.Timeout;

    if (isRunning) {
      interval = setInterval(() => {
        setSeconds(prev => {
          const newValue = prev + 1;
          onTick?.(newValue);
          return newValue;
        });
      }, 1000);
    }

    return () => clearInterval(interval);
  }, [isRunning, onTick]);

  const start = useCallback(() => setIsRunning(true), []);
  const pause = useCallback(() => setIsRunning(false), []);
  const stop = useCallback(() => {
    setIsRunning(false);
    setSeconds(0);
  }, []);

  const calculateEarnings = useCallback(() => {
    const hourlyRate = person === 'maru' ? 275 : 400;
    const hours = seconds / 3600;
    const earnings = hours * hourlyRate;
    const deductionRate = person === 'maru' ? 1/3 : 1/2;
    const deduction = earnings * deductionRate;

    return {
      earnings,
      deduction,
      net: earnings - deduction
    };
  }, [seconds, person]);

  return {
    isRunning,
    seconds,
    person,
    setPerson,
    start,
    pause,
    stop,
    calculateEarnings
  };
};
