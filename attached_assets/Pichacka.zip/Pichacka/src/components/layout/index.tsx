
import { Outlet, useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';

export const Layout = () => {
  const navigate = useNavigate();
  const user = JSON.parse(localStorage.getItem('user') || 'null');

  const handleLogout = () => {
    localStorage.removeItem('user');
    navigate('/login');
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <nav className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-16">
            <div className="flex">
              <div className="flex-shrink-0 flex items-center">
                <h1 className="text-xl font-bold">Píchačka</h1>
              </div>
            </div>
            <div className="flex items-center">
              <span className="mr-4">Přihlášen jako: {user?.name}</span>
              <Button variant="outline" onClick={handleLogout}>
                Odhlásit
              </Button>
            </div>
          </div>
        </div>
      </nav>
      <main className="py-10">
        <Outlet />
      </main>
    </div>
  );
};
