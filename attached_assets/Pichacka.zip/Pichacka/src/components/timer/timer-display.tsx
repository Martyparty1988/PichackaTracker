
import React from 'react';
import { motion } from 'framer-motion';

interface TimerDisplayProps {
  seconds: number;
  isRunning: boolean;
}

export const TimerDisplay: React.FC<TimerDisplayProps> = ({ seconds, isRunning }) => {
  const hours = Math.floor(seconds / 3600);
  const minutes = Math.floor((seconds % 3600) / 60);
  const remainingSeconds = seconds % 60;

  return (
    <motion.div 
      className="flex flex-col items-center justify-center p-8"
      animate={{
        scale: isRunning ? [1, 1.02, 1] : 1,
      }}
      transition={{
        duration: 2,
        repeat: isRunning ? Infinity : 0,
      }}
    >
      <div className="text-6xl font-bold">
        {String(hours).padStart(2, '0')}:
        {String(minutes).padStart(2, '0')}:
        {String(remainingSeconds).padStart(2, '0')}
      </div>
    </motion.div>
  );
};
