
import React from 'react';
import { Button } from '../ui/button';
import { PlayCircle, PauseCircle, StopCircle, User } from 'lucide-react';

interface TimerControlsProps {
  isRunning: boolean;
  onStart: () => void;
  onPause: () => void;
  onStop: () => void;
  person: 'maru' | 'marty';
  onPersonChange: (person: 'maru' | 'marty') => void;
}

export const TimerControls: React.FC<TimerControlsProps> = ({
  isRunning,
  onStart,
  onPause,
  onStop,
  person,
  onPersonChange,
}) => {
  return (
    <div className="flex flex-col gap-4">
      <div className="flex justify-center gap-4">
        <Button
          variant="outline"
          size="lg"
          className={`${person === 'maru' ? 'bg-purple-200' : ''}`}
          onClick={() => onPersonChange('maru')}
        >
          <User className="mr-2" />
          Maru (275 Kč/h)
        </Button>
        <Button
          variant="outline"
          size="lg"
          className={`${person === 'marty' ? 'bg-orange-200' : ''}`}
          onClick={() => onPersonChange('marty')}
        >
          <User className="mr-2" />
          Marty (400 Kč/h)
        </Button>
      </div>
      
      <div className="flex justify-center gap-4">
        {!isRunning ? (
          <Button size="lg" onClick={onStart}>
            <PlayCircle className="mr-2" />
            Start
          </Button>
        ) : (
          <Button size="lg" variant="secondary" onClick={onPause}>
            <PauseCircle className="mr-2" />
            Pauza
          </Button>
        )}
        <Button size="lg" variant="destructive" onClick={onStop}>
          <StopCircle className="mr-2" />
          Stop
        </Button>
      </div>
    </div>
  );
};
