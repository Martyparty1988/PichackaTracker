
import React from 'react';
import { WorkLog } from '@/lib/types';
import { formatDistance } from 'date-fns';
import { cs } from 'date-fns/locale';

interface WorkLogListProps {
  logs: WorkLog[];
}

export const WorkLogList: React.FC<WorkLogListProps> = ({ logs }) => {
  return (
    <div className="space-y-4">
      <h2 className="text-2xl font-bold">Pracovní záznamy</h2>
      <div className="divide-y">
        {logs.map((log) => (
          <div key={log.id} className="py-4">
            <div className="flex justify-between items-center">
              <div>
                <p className="font-semibold">{log.person}</p>
                <p className="text-sm text-gray-500">
                  {formatDistance(log.startTime, log.endTime, { locale: cs })}
                </p>
              </div>
              <div className="text-right">
                <p className="font-semibold">{log.earnings.toFixed(2)} Kč</p>
                <p className="text-sm text-red-500">
                  Srážka: {log.deduction.toFixed(2)} Kč
                </p>
                <p className="text-sm text-green-500">
                  Čistý výdělek: {log.net.toFixed(2)} Kč
                </p>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
