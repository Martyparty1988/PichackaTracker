
import React from 'react';
import { DebtRecord, FinanceSettings } from '@/lib/types';

interface FinanceDashboardProps {
  debts: DebtRecord[];
  settings: FinanceSettings;
  totalEarnings: number;
  totalDeductions: number;
}

export const FinanceDashboard: React.FC<FinanceDashboardProps> = ({
  debts,
  settings,
  totalEarnings,
  totalDeductions
}) => {
  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-white p-6 rounded-lg shadow">
          <h3 className="text-lg font-semibold">Celkové výdělky</h3>
          <p className="text-2xl font-bold">{totalEarnings.toFixed(2)} Kč</p>
        </div>
        <div className="bg-white p-6 rounded-lg shadow">
          <h3 className="text-lg font-semibold">Celkové srážky</h3>
          <p className="text-2xl font-bold text-red-500">{totalDeductions.toFixed(2)} Kč</p>
        </div>
        <div className="bg-white p-6 rounded-lg shadow">
          <h3 className="text-lg font-semibold">Nájem</h3>
          <p className="text-2xl font-bold">{settings.rentAmount.toFixed(2)} Kč</p>
        </div>
      </div>

      <div className="bg-white p-6 rounded-lg shadow">
        <h3 className="text-lg font-semibold mb-4">Dluhy</h3>
        <div className="space-y-4">
          {debts.map((debt) => (
            <div key={debt.id} className="border-b pb-4">
              <div className="flex justify-between items-center">
                <div>
                  <p className="font-semibold">{debt.description}</p>
                  <p className="text-sm text-gray-500">
                    {debt.date.toLocaleDateString()}
                  </p>
                </div>
                <div className="text-right">
                  <p className="font-semibold">{debt.amount.toFixed(2)} Kč</p>
                  <p className="text-sm text-green-500">
                    Zaplaceno: {debt.paid.toFixed(2)} Kč
                  </p>
                  <p className="text-sm text-red-500">
                    Zbývá: {debt.remainingAmount.toFixed(2)} Kč
                  </p>
                </div>
              </div>
              <div className="mt-2 w-full bg-gray-200 rounded-full h-2.5">
                <div
                  className="bg-blue-600 h-2.5 rounded-full"
                  style={{
                    width: `${(debt.paid / debt.amount) * 100}%`
                  }}
                ></div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
