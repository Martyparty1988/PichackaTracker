
export interface WorkLog {
  id: string;
  startTime: Date;
  endTime: Date;
  duration: number;
  person: 'maru' | 'marty';
  earnings: number;
  deduction: number;
  net: number;
}

export interface DebtRecord {
  id: string;
  amount: number;
  description: string;
  date: Date;
  paid: number;
  remainingAmount: number;
}

export interface FinanceSettings {
  maruRate: number;
  martyRate: number;
  maruDeduction: number;
  martyDeduction: number;
  rentAmount: number;
}
