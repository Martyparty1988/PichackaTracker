
import React from 'react';
import { TimerDisplay } from '@/components/timer/timer-display';
import { TimerControls } from '@/components/timer/timer-controls';
import { useTimer } from '@/hooks/use-timer';

export const HomePage: React.FC = () => {
  const {
    isRunning,
    seconds,
    person,
    setPerson,
    start,
    pause,
    stop,
    calculateEarnings
  } = useTimer();

  const handleStop = () => {
    const { earnings, deduction, net } = calculateEarnings();
    // TODO: Implementovat ukládání do databáze
    console.log('Výdělek:', earnings, 'Srážka:', deduction, 'Čistý výdělek:', net);
    stop();
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-4xl font-bold text-center mb-8">Píchačka</h1>
      <div className="max-w-md mx-auto">
        <TimerDisplay seconds={seconds} isRunning={isRunning} />
        <TimerControls
          isRunning={isRunning}
          onStart={start}
          onPause={pause}
          onStop={handleStop}
          person={person}
          onPersonChange={setPerson}
        />
      </div>
    </div>
  );
};
