
import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { FinanceSettings } from '@/lib/types';
import { Database } from '@replit/database';

const db = new Database();

export const SettingsPage: React.FC = () => {
  const [settings, setSettings] = useState<FinanceSettings>({
    maruRate: 275,
    martyRate: 400,
    maruDeduction: 1/3,
    martyDeduction: 1/2,
    rentAmount: 15000
  });

  const handleSave = async () => {
    await db.set('settings', settings);
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-6">Nastavení</h1>
      
      <div className="space-y-6">
        <div>
          <h2 className="text-xl font-semibold mb-4">Sazby</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700">
                Sazba Maru (Kč/h)
              </label>
              <input
                type="number"
                value={settings.maruRate}
                onChange={(e) => setSettings({
                  ...settings,
                  maruRate: Number(e.target.value)
                })}
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700">
                Sazba Marty (Kč/h)
              </label>
              <input
                type="number"
                value={settings.martyRate}
                onChange={(e) => setSettings({
                  ...settings,
                  martyRate: Number(e.target.value)
                })}
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm"
              />
            </div>
          </div>
        </div>

        <div>
          <h2 className="text-xl font-semibold mb-4">Srážky</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700">
                Srážka Maru (%)
              </label>
              <input
                type="number"
                value={settings.maruDeduction * 100}
                onChange={(e) => setSettings({
                  ...settings,
                  maruDeduction: Number(e.target.value) / 100
                })}
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700">
                Srážka Marty (%)
              </label>
              <input
                type="number"
                value={settings.martyDeduction * 100}
                onChange={(e) => setSettings({
                  ...settings,
                  martyDeduction: Number(e.target.value) / 100
                })}
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm"
              />
            </div>
          </div>
        </div>

        <div>
          <h2 className="text-xl font-semibold mb-4">Nájem</h2>
          <div>
            <label className="block text-sm font-medium text-gray-700">
              Částka nájmu (Kč)
            </label>
            <input
              type="number"
              value={settings.rentAmount}
              onChange={(e) => setSettings({
                ...settings,
                rentAmount: Number(e.target.value)
              })}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm"
            />
          </div>
        </div>

        <Button onClick={handleSave}>Uložit nastavení</Button>
      </div>
    </div>
  );
};
